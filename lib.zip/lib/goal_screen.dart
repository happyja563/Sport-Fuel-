import 'package:flutter/material.dart';
import 'gemini_ai.dart';

class GoalScreen extends StatefulWidget {
  const GoalScreen({super.key});

  @override
  State<GoalScreen> createState() => _GoalScreenState();
}

class _GoalScreenState extends State<GoalScreen> {
  String _result = "";

  void _buildPlan() async {
    final text = await GeminiService.instance.recommendMacrosFromDB();
    setState(() {
      _result = text ?? "No response from AI";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My goals")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: _buildPlan,
            child: const Text("Build Plan"),
          ),
          const SizedBox(height: 20),
          Text(_result),
        ],
      ),
    );
  }
}