import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'database.dart';
class GeminiService {
  GeminiService._();
  static final GeminiService instance = GeminiService._();
  static const String _modelName = 'gemini-1.5-flash';
  /// Convenience: fetch profile from DB and return a bulleted list of macro recs.
  Future<String?> recommendMacrosFromDB({String? extraContext}) async {
    try {
      final profile = await DBHelper().getProfile();
      if (profile == null) {
        debugPrint('GeminiService: No profile found in DB');
        return null;
      }
      return RecomendMacros(profile: profile, extraContext: extraContext);
    } catch (e) {
      debugPrint('GeminiService recommendMacrosFromDB error: $e');
      return null;
    }
  }
  Future<String?> RecomendMacros({
    required Map<String, dynamic> profile,
    String? extraContext,
  }) async {
    final apiKey = dotenv.env['GEMINI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty) {
      debugPrint('GeminiService: missing GEMINI_API_KEY');
      return null;
    }
    try {
      final gender = (profile['gender'] ?? 'Unspecified').toString();
      final age = (profile['age'] ?? 0).toString();
      final sportsType = (profile['sportsType'] ?? 'Unspecified').toString();
      final weight = (profile['weight'] ?? 0.0).toString();
      final height = (profile['height'] ?? 0.0).toString();
      final ctx = (extraContext != null && extraContext.trim().isNotEmpty)
          ? "Context: ${extraContext.trim()}\n"
          : "";
      final userPrompt =
      '''
You are a concise nutrition coach.

Based on this user's profile, provide macro recommendations:
Gender: $gender
Age: $age
Sports Type: $sportsType
Weight (kg): $weight
Height (cm): $height
$ctx
Rules:
- Output ONLY a bulleted list (no heading, no intro, no numbering).
- Each bullet: key/value style, ≤15 words.
- Include these bullets in this order:
  • Maintenance calories — <kcal> (brief method)
  • Target calories — <kcal> (goal rationale)
  • Protein — <g/day> (~<g/kg>), food examples
  • Carbs — <g/day>, timing notes
  • Fats — <g/day>, sources
  • Fiber — <g/day>, sources
  • Hydration — <L/day>
''';

      final model = GenerativeModel(model: _modelName, apiKey: apiKey);
      final response = await model.generateContent([Content.text(userPrompt)]);

      final text = response.text?.trim();
      if (text == null || text.isEmpty) return null;
      return text;
    } catch (e) {
      debugPrint('GeminiService error: $e');
      return null;
    }
    }
      // health_history may come as JSON text or List<String>

}
