import 'package:flutter/material.dart';
import 'database.dart';
class ProfileScreen extends StatefulWidget {

  const ProfileScreen ({super.key});

  @override
  State<ProfileScreen> createState() => _State();
  }

  class _State extends State<ProfileScreen> {
    String Name="Haowen";
    String Age="20";
    String Gender="Male";
    String SportType="fencing";
    String Weight="60kilograms";
    String Height="172cm";

    bool _loading = true;
    final DBHelper _db = DBHelper();

    @override
    void initState() {
      super.initState();
      _loadProfile();
    }
    Future<void> _loadProfile() async {
      final p = await _db.getProfile();
      setState(() {
        Name = (p?['name'] ?? Name).toString();
        Age = (p?['age'] ?? '').toString();
        Gender = (p?['gender'] ?? '').toString();
        SportType = (p?['sportsType'] ?? '').toString();
        Weight = (p?['weight'] ?? '').toString();
        Height = (p?['height'] ?? '').toString();
        _loading = false;
      });
    }

    String _show(String s) => (s.isEmpty) ? '—' : s;

    Future<void> _openEditSheet() async {
      final nameC = TextEditingController(text: Name);
      final ageC = TextEditingController(text: Age);
      final heightC = TextEditingController(text: Height);
      final genderC = TextEditingController(text: Gender);
      final weightC = TextEditingController(text: Weight);
      final sportypeC = TextEditingController(text: SportType);
      final formKey = GlobalKey<FormState>();
      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        builder: (ctx) {
          return Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
            ),
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Edit Profile',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: nameC,
                    decoration: const InputDecoration(labelText: 'Name'),
                    validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
                    textInputAction: TextInputAction.next,
                  ),
                  TextFormField(
                    controller: ageC,
                    decoration: const InputDecoration(labelText: 'Age'),
                    keyboardType: TextInputType.number,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return null; // optional
                      final n = int.tryParse(v);
                      if (n == null || n < 0) return 'Enter a valid age';
                      return null;
                    },
                    textInputAction: TextInputAction.next,
                  ),
                  TextFormField(
                    controller: genderC,
                    decoration: const InputDecoration(labelText: 'Gender'),
                    textInputAction: TextInputAction.next,
                  ),
                  TextFormField(
                    controller: sportypeC,
                    decoration: const InputDecoration(labelText: 'Sports Type'),
                    textInputAction: TextInputAction.next,
                  ),
                  TextFormField(
                    controller: weightC,
                    decoration: const InputDecoration(labelText: 'Weight (kg)'),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return null; // optional
                      final n = double.tryParse(v);
                      if (n == null || n <= 0) return 'Enter a valid weight';
                      return null;
                    },
                    textInputAction: TextInputAction.next,
                  ),
                  TextFormField(
                    controller: heightC,
                    decoration: const InputDecoration(labelText: 'Height (cm)'),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return null; // optional
                      final n = double.tryParse(v);
                      if (n == null || n <= 0) return 'Enter a valid height';
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Cancel'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () async {
                            if (!formKey.currentState!.validate()) return;

                            await _db.saveProfile({
                              'name': nameC.text.trim(),
                              'age': int.tryParse(ageC.text.trim()),
                              'gender': genderC.text.trim(),
                              'sportsType': sportypeC.text.trim(),
                              'weight': double.tryParse(weightC.text.trim()),
                              'height': double.tryParse(heightC.text.trim()),
                            });

                            if (!mounted) return;
                            Navigator.pop(ctx);
                            await _loadProfile();
                          },
                          child: const Text('Save'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(title: Text("Profile screen"),
        actions: [IconButton(onPressed: (){},
            icon: Icon(Icons.account_circle_sharp))],
        ),
        body:ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(

              title: Text("Name",style: TextStyle(fontSize: 25),),
              subtitle: Text(Name,style: TextStyle(fontSize: 20),),
            ),
            ListTile(
              title: Text("Weight",style: TextStyle(fontSize: 25),),
              subtitle: Text(Weight,style: TextStyle(fontSize: 20),),
            ),
          ListTile(
            title: Text("Gender",style: TextStyle(fontSize: 25),),
            subtitle: Text(Gender,style: TextStyle(fontSize: 20),),
          ),
          ListTile(
            title: Text("Sport Type",style: TextStyle(fontSize: 25),),
            subtitle: Text(SportType,style: TextStyle(fontSize: 20),),
          ),
            ListTile(
             title: Text("Height",style: TextStyle(fontSize: 25),),
              subtitle: Text(Height,style: TextStyle(fontSize: 20),),
            ),
          ListTile(
            title: Text("Age",style: TextStyle(fontSize: 25),),
            subtitle: Text(Age,style: TextStyle(fontSize: 20),),
          ),
          Center(child: ElevatedButton(onPressed:_openEditSheet,
              child: Text("Edit Profile")))],
        ),
      );
    }
  }
