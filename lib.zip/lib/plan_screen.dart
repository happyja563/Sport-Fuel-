import 'package:flutter/material.dart';

class FoodTrackerScreen extends StatefulWidget {
  const FoodTrackerScreen({super.key});

  @override
  State<FoodTrackerScreen> createState() => _FoodTrackerScreenState();
}

class _FoodTrackerScreenState extends State<FoodTrackerScreen> {
  final List<String> _days = const [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  late int _selectedDayIndex; // 0 = Mon ... 6 = Sun

  // --- Mock data (frontend only). Replace with your DB later. ---
  final Map<String, List<FoodEntry>> _entriesByDay = {
    'Mon': [
      FoodEntry(name: 'Oatmeal + Banana', time: '07:45 AM'),
      FoodEntry(name: 'Chicken Bowl', time: '12:30 PM'),
      FoodEntry(name: 'Greek Yogurt', time: '04:10 PM'),
    ],
    'Tue': [
      FoodEntry(name: 'Eggs & Toast', time: '08:05 AM'),
      FoodEntry(name: 'Beef Stir Fry', time: '01:00 PM'),
    ],
    'Wed': [FoodEntry(name: 'Protein Shake', time: '09:15 AM')],
    'Thu': [],
    'Fri': [
      FoodEntry(name: 'Breakfast Burrito', time: '08:20 AM'),
      FoodEntry(name: 'Salmon + Rice', time: '01:15 PM'),
      FoodEntry(name: 'PB Sandwich', time: '05:40 PM'),
    ],
    'Sat': [],
    'Sun': [],
  };

  @override
  void initState() {
    super.initState();
    _selectedDayIndex = _weekdayToIndex(DateTime.now().weekday);
  }

  int _weekdayToIndex(int weekday) {
    // DateTime.weekday: Mon=1 ... Sun=7 -> convert to 0..6
    return (weekday - 1).clamp(0, 6);
  }

  @override
  Widget build(BuildContext context) {
    final String selectedDayLabel = _days[_selectedDayIndex];
    final List<FoodEntry> entries = _entriesByDay[selectedDayLabel] ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('Food Tracker')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Top-right: horizontal list of day buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: 40,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  reverse: false,
                  itemCount: _days.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final isSelected = index == _selectedDayIndex;
                    return OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        side: BorderSide(
                          color: isSelected
                              ? Theme.of(context).colorScheme.primary
                              : Theme.of(context).dividerColor,
                        ),
                        backgroundColor: isSelected
                            ? Theme.of(
                          context,
                        ).colorScheme.primary.withOpacity(0.08)
                            : null,
                      ),
                      onPressed: () {
                        setState(() => _selectedDayIndex = index);
                      },
                      child: Text(_days[index]),
                    );
                  },
                ),
              ),
            ),
          ),

          const Divider(height: 1),

          // Bottom: list showing current day's items & times
          Expanded(
            child: entries.isEmpty
                ? _EmptyState(day: selectedDayLabel)
                : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final e = entries[i];
                return ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                  title: Text(e.name),
                  trailing: Text(
                    e.time,
                    style: Theme.of(context).textTheme.bodySmall
                        ?.copyWith(
                      fontFeatures: const [
                        FontFeature.tabularFigures(),
                      ],
                    ),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.day});
  final String day;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Text(
          'No items added for $day yet.',
          style: Theme.of(context).textTheme.bodyMedium,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class FoodEntry {
  final String name;
  final String time; // e.g., '08:15 AM'

  const FoodEntry({required this.name, required this.time});
}
