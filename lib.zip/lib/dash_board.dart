import 'package:flutter/material.dart';
class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            // Left vertical rectangle (Motivational Quote)
            Expanded(
              flex: 1,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green[300],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Center(
                  child: Text(
                    "\"Push yourself, because no one else is going to do it for you.\"",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),

            // Right side (two stacked squares)
            Expanded(
              flex: 1,
              child: Column(
                children: [
                  // Top right square (Macro Goals)
                  Expanded(
                    child: Container(
                      constraints: const BoxConstraints.expand(),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue[300],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Macro Goals",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Calories: 0 / 2000",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            "Protein: 0 / 70 g",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            "Carbs: 0 / 300 g",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            "Fats: 2 / 20 g",
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Bottom right square (Today's Goals)
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.red[300],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Today's Goals",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Expanded(
                            child: ListView(
                              children: const [
                                CheckboxListTile(
                                  title: Text(
                                    "Workout",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  value: false,
                                  onChanged: null,
                                  // Make functional later
                                  controlAffinity:
                                  ListTileControlAffinity.leading,
                                  contentPadding: EdgeInsets.zero,
                                ),
                                CheckboxListTile(
                                  title: Text(
                                    "Drink 3L Water",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  value: false,
                                  onChanged: null,
                                  controlAffinity:
                                  ListTileControlAffinity.leading,
                                  contentPadding: EdgeInsets.zero,
                                ),
                                CheckboxListTile(
                                  title: Text(
                                    "Sleep 8 hrs",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  value: false,
                                  onChanged: null,
                                  controlAffinity:
                                  ListTileControlAffinity.leading,
                                  contentPadding: EdgeInsets.zero,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }}